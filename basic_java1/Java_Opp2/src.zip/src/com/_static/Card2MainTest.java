package com._static;

public class Card2MainTest {

    public static void main(String[] args) {

        // Card2.cardCounter = 110;
        Card2 card1 = new Card2("카드1");
        Card2 card2 = new Card2("카드2");
        Card2 card3 = new Card2("카드3");
        card1.showInfo();
        card2.showInfo();
        card3.showInfo();


    }
}
